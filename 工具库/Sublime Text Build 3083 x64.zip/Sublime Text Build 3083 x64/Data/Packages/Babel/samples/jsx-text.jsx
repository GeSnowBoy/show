/**
 * These have always work
 */
<div>
  {'it\'s with text inside'}
</div>

<div>{'it\'s with text inside'}</div>

<div
  attr=''>
  {'it\'s with text inside'}
</div>

<div attr="">{'it\'s with text inside'}</div>
<div
  attr="">
  {"it's with text inside"}
</div>

<div attr={}>{"it's with text inside"}</div>
<div
  attr={}>
  {"it's with text inside"}
</div>


/**
 * Fixed
 */
<div>
  it's with text inside
</div>

<div>it's with text inside</div>

<div
  attr=''>
  it's with text inside
</div>

<div attr="">it's with text inside</div>
<div
  attr="">
  it's with text inside
</div>

<div attr={}>it's with text inside</div>
<div
  attr={}>
  it's with text inside
</div>

<div attr>it's with text inside</div>

<div
  >it's with text inside</div>

<div
  attr={}
  >it's with text inside</div>
